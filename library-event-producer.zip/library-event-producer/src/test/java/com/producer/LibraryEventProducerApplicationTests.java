package com.producer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryEventProducerApplicationTests {

	@Test
	void contextLoads() {
	}

}
